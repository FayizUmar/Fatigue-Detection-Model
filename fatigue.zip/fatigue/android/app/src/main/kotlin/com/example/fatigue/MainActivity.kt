package com.example.fatigue

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
